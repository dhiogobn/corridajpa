package acc.br.corridajpa.repository;

import acc.br.corridajpa.model.Corrida;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CorridaRepository extends JpaRepository<Corrida, Long>
{
    List<Corrida> findByLocalId(Long localId);

    @Transactional
    void deleteByLocalId(Long localId);
}
